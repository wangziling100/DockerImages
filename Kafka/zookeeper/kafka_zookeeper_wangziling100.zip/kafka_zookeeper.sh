/usr/kafka_zookeeper/bin/zookeeper-server-start.sh $ZOOKEEPER_CONFIG
