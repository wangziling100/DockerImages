/usr/kafka_consumer/bin/kafka-console-consumer.sh --bootstrap-server $KAFKA_SERVER:$KAFKA_SERVER_PORT --topic $KAFKA_CONSUMER_TOPIC $KAFKA_CONSUMER_FROM_BEGINNING
